package com.scb.message;
import java.util.Properties;  
import javax.mail.*;
import javax.mail.Message.RecipientType;
import javax.mail.internet.*;  
  
public class SendEmail {  
 public static void main(String[] args) {  
  
  String host="smtp.gmail.com";  
  final String user="apsingh1036@gmail.com";//change accordingly  
  final String password="qtkujddqhzlokjdd";//change accordingly  
    
  String to="swatiarya942@gmail.com";//change accordingly  
  
   //Get the session object  
   Properties props = new Properties();  
   props.put("mail.smtp.host",host);  
   props.put("mail.smtp.auth", "true");  
   props.put("mail.smtp.port", "465"); 
   props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
   Session session = Session.getDefaultInstance(props,  
    new javax.mail.Authenticator() {  
      protected PasswordAuthentication getPasswordAuthentication() {  
    return new PasswordAuthentication(user,password);  
      }  
    });  
  
   //Compose the message  
    try {  
     MimeMessage message = new MimeMessage(session);  
     message.setFrom(new InternetAddress(user));  
     message.addRecipient(RecipientType.TO,new InternetAddress(to));  
     message.setSubject("Credit Card Successfully Generated");  
     message.setText("Congratulations on getting new Credit Card.Thank you for choosing SCB");  
       
    //send the message  
     Transport.send(message);  
  
     System.out.println("message sent successfully...");  
   
     } catch (MessagingException e) {e.printStackTrace();}  
 }  
}  